<!-- <a class="link" href="https://learnjavascript.online?utm_source=codetogo.io;" target="_blank" rel="noopener">Learn JavaScript</a> -->
<a class="link" href="/all">Use Cases</a>
<a class="link hide-mobile" id="contribute" href="https://github.com/jadjoubran/codetogo.io/issues/new?title=Use+Case+Suggestion: " target="_blank" rel="noopener">Contribute</a>
