<nav>
    <div class="container">
        <div class="nav-container nav-spacer">
            <a href="/">
                <div id="logo">
                   @include('_partials/logosvg')
                   <div class="hide-mobile">Code to go</div>
               </div>
           </a>
           <div id="menu">
            @include('_partials.menu')
        </div>
    </div>
</div>
</nav>
