<footer>
    <div class="container">
        <div class="footer-container">
            <div>
                Designed by
                <a href="https://nicolesaidy.com" target="_blank" rel="noopener">Nicole Saidy</a>, 
                built by
                <a href="https://jadjoubran.io" target="_blank" rel="noopener">Jad Joubran</a> &amp; <a href="https://github.com/jadjoubran/codetogo.io/graphs/contributors" target="_blank" rel="noopener nofollower">contributors</a>
            </div>
            <div class="links">
                <a href="/about">
                    <div class="link">About</div>
                </a>
            </div>
        </div>
    </div>
</footer>
