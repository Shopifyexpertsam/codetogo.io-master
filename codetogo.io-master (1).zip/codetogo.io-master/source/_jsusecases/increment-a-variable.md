---
extends: _layouts.usecase
date: 2024-02-27
link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Arithmetic_Operators
reference: Arithmetic operators
related: decrement-a-variable
category: syntax
---

```javascript
let counter = 0;
counter++;
console.log(counter);
```

<pre class="output">1</pre>
