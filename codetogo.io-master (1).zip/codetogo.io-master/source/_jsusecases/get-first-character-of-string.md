---
extends: _layouts.usecase
date: 2018-12-26
related: get-last-character-of-string
category: strings
---

```javascript
const name = "William moore";

name[0];
```

<pre class="output">W</pre>
