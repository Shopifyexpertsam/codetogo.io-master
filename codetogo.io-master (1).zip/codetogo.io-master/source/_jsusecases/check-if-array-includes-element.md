---
extends: _layouts.usecase
date: 2017-12-16
link: https://blog.learnjavascript.online/posts/javascript-in-array/
reference_website: Learn JavaScript Blog
reference: JavaScript in array
category: arrays
---

```javascript
const apps = ["phone", "calculator", "clock"];

apps.includes("calculator");
```

<pre class="output">true</pre>
