---
extends: _layouts.usecase
date: 2024-02-27
link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Arithmetic_Operators
reference: Arithmetic operators
related: increment-a-variable
category: numbers
---

```javascript
let limit = 10;
limit--;
console.log(limit);
```

<pre class="output">9</pre>
