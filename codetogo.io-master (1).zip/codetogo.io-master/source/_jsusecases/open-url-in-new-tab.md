---
extends: _layouts.usecase
date: 2018-04-28
link: https://developer.mozilla.org/en-US/docs/Web/API/Window/open
reference: Window.open
category: URL
---

```javascript
window.open("https://example.com");
```
