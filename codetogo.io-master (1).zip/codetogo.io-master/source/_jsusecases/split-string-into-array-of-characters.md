---
extends: _layouts.usecase
date: 2017-12-16
category: arrays
---

```javascript
const arrayOfChars = [..."hello world"];
```

<pre class="output">
['h', 'e', 'l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd']
</pre>
