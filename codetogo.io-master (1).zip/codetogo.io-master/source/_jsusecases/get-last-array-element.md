---
extends: _layouts.usecase
date: 2024-02-28
link: https://blog.learnjavascript.online/posts/javascript-at-method/
reference: String.at()
reference_website: Learn JavaScript Blog
category: arrays
related: get-last-character-of-string
---

```javascript
const apps = ["phone", "calculator", "clock"];

apps.at(-1);
```

<pre class="output">"clock"</pre>
