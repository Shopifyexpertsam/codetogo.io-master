---
extends: _layouts.usecase
date: 2017-11-11
link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object
reference: Object
category: objects
---

```javascript
const person = {
  key: "value",
  first_name: "John",
  last_name: "Doe"
};
```
