---
extends: _layouts.usecase
date: 2024-02-26
link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals
reference: Template literals
related: interpolate
category: strings
---

```javascript
const text = `Using the backtick character,
you can define a string that
spans multiple lines.`;
```
