---
extends: _layouts.usecase
date: 2018-04-28
link: https://developer.mozilla.org/en-US/docs/Web/API/Location
reference: Location.port
related: get-current-page-url
category: URL
---

```javascript
window.location.port;
```
