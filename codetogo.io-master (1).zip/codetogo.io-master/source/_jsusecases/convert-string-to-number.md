---
extends: _layouts.usecase
date: 2017-11-11
link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number/parseInt
reference: Number.parseInt
category: numbers
---

```javascript
Number.parseInt("24", 10);
```

<pre class="output">24</pre>
