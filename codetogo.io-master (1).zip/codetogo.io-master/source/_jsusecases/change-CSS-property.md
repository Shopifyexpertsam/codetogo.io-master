---
extends: _layouts.usecase
date: 2018-03-11
category: DOM
---

```html
<div id="box"></div>
```

```javascript
const element = document.querySelector("#box");

//change background-color
element.style.backgroundColor = "red";
```
