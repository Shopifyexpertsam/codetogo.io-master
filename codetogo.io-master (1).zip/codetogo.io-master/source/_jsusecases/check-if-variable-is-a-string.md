---
extends: _layouts.usecase
date: 2018-04-28
link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/typeof
reference: typeof
category: strings
---

```javascript
const input = "potential string";

typeof input === "string";
```

<pre class="output">true</pre>
