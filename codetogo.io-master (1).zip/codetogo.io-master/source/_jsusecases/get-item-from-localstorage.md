---
extends: _layouts.usecase
date: 2017-12-19
link: https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage
reference: Window.localStorage
related: add-item-to-localstorage
category: storage
---

```javascript
localStorage.getItem("name");
```
