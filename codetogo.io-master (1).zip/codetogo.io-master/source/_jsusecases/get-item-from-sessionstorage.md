---
extends: _layouts.usecase
date: 2017-12-21
link: https://developer.mozilla.org/en-US/docs/Web/API/Window/sessionStorage
reference: Window.sessionStorage
related: add-item-to-sessionstorage
category: storage
---

```javascript
sessionStorage.getItem("name");
```
