---
extends: _layouts.usecase
date: 2017-12-24
link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Lexical_grammar#Comments
reference: Comments
category: syntax
---

```javascript
//this is a one line comment

/*
  And this is a comment
  that spans multiple lines
*/
```
