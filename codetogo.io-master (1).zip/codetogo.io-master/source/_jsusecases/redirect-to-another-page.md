---
extends: _layouts.usecase
date: 2017-12-16
link: https://developer.mozilla.org/en-US/docs/Web/API/Window/location
reference: Window.location
category: URL
---

```javascript
window.location.href = "https://codetogo.io";
```
