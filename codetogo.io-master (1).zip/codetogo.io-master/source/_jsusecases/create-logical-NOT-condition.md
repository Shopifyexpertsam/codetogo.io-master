---
extends: _layouts.usecase
date: 2018-01-02
link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Logical_Operators
reference: Logical operators
category: syntax
---

```javascript
const isOverage = false;

if (!isOverage) {
  console.log("You are underage");
}
```

<pre class="output">You are underage</pre>
