---
extends: _layouts.usecase
date: 2018-12-26
category: strings
---

```javascript
let str = "welcome to code to go";

str = str[0].toUpperCase() + str.substring(1);
```

<pre class="output">Welcome to code to go</pre>
