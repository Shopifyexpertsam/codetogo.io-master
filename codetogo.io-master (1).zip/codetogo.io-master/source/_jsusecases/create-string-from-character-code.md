---
extends: _layouts.usecase
date: 2017-12-23
link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/fromCharCode
reference: String.fromCharCode
category: strings
---

```javascript
String.fromCharCode(67, 111, 111, 108, 46);
```

<pre class="output">Cool.</pre>
