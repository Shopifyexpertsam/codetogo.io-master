---
extends: _layouts.usecase
date: 2020-01-28
reference: Functional component
category: component
---

```jsx
import React from "react";

function MyComponent() {
  return <h1>This is a functional component</h1>;
}
```
