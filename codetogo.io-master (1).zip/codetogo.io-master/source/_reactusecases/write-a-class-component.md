---
extends: _layouts.usecase
date: 2020-01-28
reference: Class component
category: component
---

```jsx
import React from "react";

class MyComponent extends React.Component {
  constructor(props) {
    super(props);
    //
  }

  render() {
    return <h1>This is a class component</h1>;
  }
}
```
