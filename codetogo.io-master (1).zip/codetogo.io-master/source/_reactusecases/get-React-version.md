---
extends: _layouts.usecase
date: 2020-01-28
reference: React.version
category: misc
---

```jsx
import React from "react";

const version = React.version;
console.log(version);
```

<pre class="output">
16.12.0
</pre>
