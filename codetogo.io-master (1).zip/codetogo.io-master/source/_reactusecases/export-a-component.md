---
extends: _layouts.usecase
date: 2020-03-18
reference: React Component
category: React
---

```jsx
import React from "react";

export default function Navbar() {
  return <div>Navbar here</div>;
}
```
