---
extends: _layouts.usecase
date: 2020-03-18
reference: React.Fragment
category: React
---

```jsx
import React from "react";

function App() {
  return (
    <>
      <p>First element</p>
      <p>Second element</p>
    </>
  );
}
```
