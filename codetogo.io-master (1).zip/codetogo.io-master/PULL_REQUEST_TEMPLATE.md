> Put an `x` inside those square brackets to mark them as complete.

- [ ] Check [CONTRIBUTING.md](https://github.com/jadjoubran/codetogo.io/blob/master/CONTRIBUTING.md)?
- [ ] 1 use case per Pull Request
- [ ] Double check the use case file name?
- [ ] Update or remove the `mdn` link?
- [ ] Update or remove the `related` use cases?
- [ ] Update the category? (if necessary)
- [ ] Update the date?
